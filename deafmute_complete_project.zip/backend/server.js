const express = require('express');
const cors = require('cors');
const app = express();
app.use(cors());
app.use(express.json());
app.use('/signs', express.static(__dirname + '/signs'));

// Simple bilingual dictionary (English -> Kannada)
const dictionary = {
  "hello":"ಹಲೋ",
  "thank you":"ಧನ್ಯವಾದಗಳು",
  "good morning":"ಶುಭೋದಯ",
  "good night":"ಶುಭ ರಾತ್ರಿ",
  "how are you":"ನೀವು ಹೇಗಿದ್ದೀರಿ",
  "sorry":"ಕ್ಷಮಿಸಿ",
  "yes":"ಹೌದು",
  "no":"ಇಲ್ಲ",
  "please":"ದಯವಿಟ್ಟು",
  "water":"ನೀರು",
  "mother":"ತಾಯಿ",
  "father":"ತಂದೆ",
  "i love you":"ನಾನು ನಿನ್ನ ಪ್ರೀತಿಸುತ್ತೇನೆ",
  "i am dhanush":"ನಾನು ಧನುಷ್",
  "i love to eat chicken":"ನನಗೆ ಕೋಳಿ ಮಾಂಸ ತಿನ್ನಲು ಇಷ್ಟ",
  "where are you from":"ನೀವು ಎಲ್ಲಿಂದ ಬಂದವರು",
  "what is your name":"ನಿಮ್ಮ ಹೆಸರೇನು",
  "i am feeling sad":"ನನಗೆ ಬೇಸರವಾಗುತ್ತಿದೆ",
  "where is the hospital":"ಆಸ್ಪತ್ರೆ ಎಲ್ಲಿದೆ"
};

// sign image mapping (filenames inside /signs)
const signImages = {
  "hello":"hello.png",
  "thank you":"thank_you.png",
  "i love you":"i_love_you.png",
  "i am dhanush":"i_am_dhanush.png",
  "i love to eat chicken":"i_love_to_eat_chicken.png",
  "water":"water.png",
  "a":"a.png","b":"b.png","c":"c.png","d":"d.png","e":"e.png","f":"f.png","g":"g.png","h":"h.png","i":"i.png","j":"j.png","k":"k.png","l":"l.png","m":"m.png","n":"n.png","o":"o.png","p":"p.png","q":"q.png","r":"r.png","s":"s.png","t":"t.png","u":"u.png","v":"v.png","w":"w.png","x":"x.png","y":"y.png","z":"z.png"
};

function normalize(s){ if(!s) return ''; return s.normalize('NFC').trim().toLowerCase(); }

app.post('/translate', (req, res) => {
  const text = (req.body.text || '').toString();
  const mode = req.body.mode || 'en-kn'; // en-kn or kn-en
  const input = normalize(text);

  let translation = 'Translation not found';
  if(mode === 'en-kn'){
    translation = dictionary[input] || 'Translation not found';
  } else {
    // kn -> en (reverse lookup)
    const found = Object.entries(dictionary).find(([en, kn]) => normalize(kn) === input);
    translation = found ? found[0] : 'Translation not found';
  }

  // determine image key (prefer English key)
  let imageKey = (mode === 'en-kn') ? input : translation.toLowerCase();
  imageKey = normalize(imageKey);

  const signImage = signImages[imageKey] || null;

  res.json({ translation, signImage });
});

const port = process.env.PORT || 5000;
app.listen(port, ()=> console.log(`🔥 Backend running on http://localhost:${port}`));
